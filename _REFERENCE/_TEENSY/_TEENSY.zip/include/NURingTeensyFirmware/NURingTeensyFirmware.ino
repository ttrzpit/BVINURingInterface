#pragma once

#include <memory>

